
  # Duplicate UI Screen

  This is a code bundle for Duplicate UI Screen. The original project is available at https://www.figma.com/design/SQhDd1ulqpBk4UBw0wCaWZ/Duplicate-UI-Screen.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  