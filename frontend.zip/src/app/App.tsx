import { useState, useEffect } from "react";
import AdminDashboard from "@/imports/AdminDashboard/index";
import Frame from "@/imports/Frame1597885036/index";

type View = "admin" | "doctor" | "patient";

const NAV_ITEMS: { id: View; label: string }[] = [
  { id: "admin", label: "Admin Dashboard" },
  { id: "doctor", label: "Doctor Dashboard" },
  { id: "patient", label: "Patient Dashboard" },
];

export default function App() {
  const [view, setView] = useState<View>("admin");

  // Wire sidebar menu click → active highlight
  useEffect(() => {
    const items = document.querySelectorAll('[data-name="Menu"]');
    const handlers: Array<{ el: Element; fn: EventListener }> = [];
    items.forEach((el) => {
      const fn: EventListener = () => {
        items.forEach((m) => m.classList.remove("menu-active"));
        el.classList.add("menu-active");
      };
      el.addEventListener("click", fn);
      handlers.push({ el, fn });
    });
    return () => handlers.forEach(({ el, fn }) => el.removeEventListener("click", fn));
  }, [view]);

  return (
    <>
      <style>{`
        /* ═══════════════════════════════════════════
           SHARED INTERACTIVE STYLES (all dashboards)
           ═══════════════════════════════════════════ */

        /* Sidebar: fixed + internally scrollable */
        [data-name="Sidebar  Scroll"] {
          position: fixed !important;
          top: 0 !important;
          left: 0 !important;
          height: 100vh !important;
          overflow-y: auto !important;
          overflow-x: hidden !important;
          z-index: 20 !important;
          scrollbar-width: thin;
          scrollbar-color: #d1d5db transparent;
        }
        [data-name="Sidebar  Scroll"]::-webkit-scrollbar { width: 3px; }
        [data-name="Sidebar  Scroll"]::-webkit-scrollbar-thumb {
          background: #d1d5db; border-radius: 4px;
        }
        [data-name="Sidebar Default"] { min-height: 100% !important; }

        /* Header: fixed to top */
        [data-name="Header"] {
          position: fixed !important;
          top: 0 !important;
          left: 276px !important;
          z-index: 30 !important;
        }

        /* ── Sidebar menu items ── */
        [data-name="Menu"] {
          cursor: pointer;
          border-radius: 6px;
          transition: background 0.15s ease;
        }
        [data-name="Menu"]:hover { background-color: #f0f1fa !important; }
        [data-name="Menu"].menu-active,
        [data-name="Menu"]:active { background-color: #e8eaf6 !important; }

        /* ── Buttons ── */
        [data-name="Button"] {
          cursor: pointer;
          transition: opacity 0.15s, transform 0.1s;
        }
        [data-name="Button"]:hover { opacity: 0.88; transform: translateY(-1px); }
        [data-name="Button"]:active { transform: translateY(0); opacity: 1; }

        /* ── Stat / Info cards ── */
        [data-name="Stat Card"] {
          cursor: default;
          transition: transform 0.15s, box-shadow 0.15s;
        }
        [data-name="Stat Card"]:hover {
          transform: translateY(-2px);
          box-shadow: 0 6px 16px rgba(0,0,0,0.09) !important;
        }
        [data-name="Doctor Info"] {
          cursor: pointer;
          transition: box-shadow 0.15s, transform 0.15s;
        }
        [data-name="Doctor Info"]:hover {
          box-shadow: 0 4px 14px rgba(0,0,0,0.1) !important;
          transform: translateY(-1px);
        }

        /* ── Dropdowns ── */
        [data-name="Input"] { cursor: pointer; transition: background 0.15s; }
        [data-name="Input"]:hover { background-color: #f0f1fa !important; }

        /* ── Calendar ── */
        [data-name="Nav"] {
          cursor: pointer;
          border-radius: 50%;
          transition: background 0.15s;
        }
        [data-name="Nav"]:hover { background-color: #e8eaf6 !important; }
        [data-name="Day"]:hover,
        [data-name="Day Cell"]:hover {
          background-color: #eef0fb !important;
          border-radius: 50%;
          cursor: pointer;
        }

        /* ── Table rows ── */
        [data-name="Table Row"]:hover {
          background-color: #f9fafb !important;
          cursor: pointer;
        }

        /* ── Legend items ── */
        [data-name="Legend Item"] { cursor: pointer; transition: background 0.15s; }
        [data-name="Legend Item"]:hover { background-color: #edf0f7 !important; }

        /* ── View All / links ── */
        [data-name="View All"]:hover,
        [data-name="See All"]:hover { cursor: pointer; opacity: 0.75; }

        /* ── Avatars ── */
        [data-name="Avatar Circle"] { cursor: pointer; transition: transform 0.15s; }
        [data-name="Avatar Circle"]:hover { transform: scale(1.08); }

        /* ── Icon containers ── */
        [data-name="Icon Container"] { transition: transform 0.15s; }
        [data-name="Icon Container"]:hover { transform: scale(1.1); }

        /* ── Appointments + Schedule rows ── */
        [data-name="Appointment"]:hover,
        [data-name="Schedule"]:hover { opacity: 0.85; cursor: pointer; }

        /* ═══════════════════════════════════
           ADMIN DASHBOARD canvas size
           ═══════════════════════════════════ */
        .admin-view [data-name="Admin Dashboard"] {
          min-height: 2450px !important;
          height: 2450px !important;
        }

        /* ═══════════════════════════════════
           FRAME (Doctor / Patient) layout
           ═══════════════════════════════════ */

        /* Frame root → give it real height */
        .doctor-view .frame-root,
        .patient-view .frame-root {
          position: relative !important;
          width: 1440px !important;
          min-height: 1960px !important;
        }

        /* Doctor view: show Doctor, hide Patient */
        .doctor-view [data-name="Doctor Dashboard"] {
          position: relative !important;
          left: 0 !important;
          top: 0 !important;
          min-height: 1960px !important;
          height: auto !important;
          overflow: visible !important;
        }
        .doctor-view [data-name="Patient Dashboard"] {
          display: none !important;
        }

        /* Patient view: hide Doctor, show Patient at left:0 */
        .patient-view [data-name="Patient Dashboard"] {
          position: relative !important;
          left: 0 !important;
          top: 0 !important;
          min-height: 1960px !important;
          height: auto !important;
          overflow: visible !important;
        }
        .patient-view [data-name="Doctor Dashboard"] {
          display: none !important;
        }

        /* ═══════════════════════════════════
           NAV SWITCHER PILLS
           ═══════════════════════════════════ */
        .dash-nav {
          position: fixed;
          top: 11px;
          right: 340px;
          z-index: 200;
          display: flex;
          gap: 4px;
          background: rgba(255,255,255,0.95);
          border: 1px solid #e7e8eb;
          border-radius: 8px;
          padding: 3px;
          box-shadow: 0 1px 4px rgba(0,0,0,0.08);
        }
        .dash-nav button {
          padding: 3px 10px;
          border-radius: 6px;
          font-size: 12px;
          font-weight: 600;
          font-family: 'Inter', sans-serif;
          cursor: pointer;
          border: none;
          transition: all 0.15s;
          white-space: nowrap;
        }
        .dash-nav button.active {
          background: #2e37a4;
          color: #fff;
        }
        .dash-nav button:not(.active) {
          background: transparent;
          color: #0a1b39;
        }
        .dash-nav button:not(.active):hover {
          background: #f0f1fa;
        }
      `}</style>

      {/* Dashboard switcher — floats inside the header bar */}
      <nav className="dash-nav">
        {NAV_ITEMS.map(({ id, label }) => (
          <button
            key={id}
            className={view === id ? "active" : ""}
            onClick={() => setView(id)}
          >
            {label}
          </button>
        ))}
      </nav>

      {/* ── Admin Dashboard ── */}
      {view === "admin" && (
        <div
          className="admin-view"
          style={{
            width: "100%",
            minHeight: "100vh",
            overflowX: "auto",
            overflowY: "auto",
            background: "#f5f6f8",
          }}
        >
          <AdminDashboard />
        </div>
      )}

      {/* ── Doctor Dashboard ── */}
      {view === "doctor" && (
        <div
          className="doctor-view"
          style={{
            width: "100%",
            minHeight: "100vh",
            overflowX: "auto",
            overflowY: "auto",
            background: "#f5f6f8",
          }}
        >
          {/* wrapper gives Frame a real reference size */}
          <div className="frame-root">
            <Frame />
          </div>
        </div>
      )}

      {/* ── Patient Dashboard ── */}
      {view === "patient" && (
        <div
          className="patient-view"
          style={{
            width: "100%",
            minHeight: "100vh",
            overflowX: "auto",
            overflowY: "auto",
            background: "#f5f6f8",
          }}
        >
          <div className="frame-root">
            <Frame />
          </div>
        </div>
      )}
    </>
  );
}
